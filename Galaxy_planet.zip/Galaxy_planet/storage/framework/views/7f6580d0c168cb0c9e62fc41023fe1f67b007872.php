<?php $__env->startSection('content'); ?>
    <div class="jumbotron text-center">
        <h1>Welcome to the project work of Laravel</h1>
        <h3>Here we need to create somethings:</h3>
        <ul>
            <li>Create a database with the following details</li>
            <li>Planet table with the following fields, name of Planet, Id</li>
            <li>Galaxy table with names of galaxy and id for the same</li>
            <li>An association between the 2 tables to establish galaxy as a category of planet</li>
            <li>Then create a view to search through the fields. That should give results on both: searching galaxy will lead to all planets</li>
            <li>Searching a specific planet will give you a planet as a result</li>
        </ul>
        <a class="btn btn-primary ltn-lg" href="/main" role="button">Main page</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>