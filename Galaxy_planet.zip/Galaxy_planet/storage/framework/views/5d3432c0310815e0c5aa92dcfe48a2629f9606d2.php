<?php $__env->startSection('content'); ?>
    <h1>Edit Planet:</h1>
    <?php echo Form::open(['action' => ['PlanetsController@update', $planet->id],'method'=>'POST']); ?>

        <div class="form-group">
            <?php echo e(Form::label('planet','Planet')); ?>

            <?php echo e(Form::text('planet',$planet->planet,['class'=>'form-control','placeholder'=> "Planet Name"])); ?>

            <?php echo e(Form::label('galaxy_id','Galaxy_ID')); ?>

            <?php echo e(Form::text('galaxy_id',$planet->galaxy_id,['class'=>'form-control','placeholder'=> "Galaxy ID"])); ?>

        </div>
        <?php echo e(Form::hidden('_method','PUT')); ?>

        <?php echo e(Form::submit('Submit',['class'=>'btn btn-primary'])); ?>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>