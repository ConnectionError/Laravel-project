<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <h3>The user Logged in</h3>
                    <a href="/planets/create" class="btn btn-primary">Create Planet</a></li>
                    <a href="/galaxies/create" class="btn btn-primary">Create Galaxy</a></li>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><h2>Planetory System</h2></div>
                <div class="container">
                    <table style= "width:250px">
                        <tr>
                            <th class="table-heading">Planet Name</th>
                            <th class="table-heading">Galaxy Name</th>
                        </tr>
                        <?php if(count($galaxes)>0): ?>
                            <?php $__currentLoopData = $galaxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(count($planets)>0): ?>
                                    <?php $__currentLoopData = $planets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $planet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($galax->id === $planet->galaxy_id): ?>
                                        <tr>
                                            <td><?php echo e($planet->planet); ?></td>
                                            <td><?php echo e($galax->galaxy); ?></td>
                                        </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>