<?php $__env->startSection('content'); ?>
    <h1>Galaxies:</h1>

    <?php if(count($galaxes)>0): ?>
        <?php $__currentLoopData = $galaxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="well">
            <h3><a href="/galaxies/<?php echo e($galax->id); ?>"><?php echo e($galax->galaxy); ?></a></h3>
            <small>Written on:<?php echo e($galax->created_at); ?></small>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>