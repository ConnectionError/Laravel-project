<?php $__env->startSection('content'); ?>
    <h1>Planets:</h1>

    <?php if(count($planets)>0): ?>
        <?php $__currentLoopData = $planets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $planet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="well">
            <h3><a href="/planets/<?php echo e($planet->id); ?>"><?php echo e($planet->planet); ?></a></h3>
            <small>Written on:<?php echo e($planet->created_at); ?></small>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>