<?php $__env->startSection('content'); ?>
    <a href="\planets" class="btn btn-default">Go Back</a>
    <h1><?php echo e($planet->planet); ?></h1>
    <hr>
    <h3 style="color:white">The Planet having Galaxy ID: <?php echo e($planet->galaxy_id); ?></h3>
    <small style="color:white">Written on: <?php echo e($planet->created_at); ?></small>
    <hr>
    <?php if(!Auth::guest()): ?>
        <a href="/planets/<?php echo e($planet->id); ?>/edit" class="btn btn-default">Edit</a>
        <?php echo Form::open(['action' => ['PlanetsController@destroy',$planet->id], 'method'=>'POST', 'class'=> 'pull-right']); ?>

            <?php echo e(Form::hidden('_method', 'DELETE')); ?>

            <?php echo e(Form::submit('Delete', ['class'=>'btn btn-danger'])); ?>

        <?php echo Form::close(); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>