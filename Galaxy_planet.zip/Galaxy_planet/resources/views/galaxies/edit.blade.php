@extends('layouts.app')
@section('content')
    <h1>Edit Galaxy:</h1>
    {!! Form::open(['action' => ['GalaxiesController@update', $galax->id],'method'=>'POST']) !!}
        <div class="form-group">
            {{Form::label('galaxy','Galaxy')}}
            {{Form::text('galaxy',$galax->galaxy,['class'=>'form-control','placeholder'=> "GalaxyName"])}}
        </div>
        {{Form::hidden('_method','PUT')}}
        {{Form::submit('Submit',['class'=>'btn btn-primary'])}}
    {!! Form::close() !!}
@endsection