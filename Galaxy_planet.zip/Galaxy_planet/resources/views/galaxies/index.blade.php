@extends('layouts.app')
@section('content')
    <h1>Galaxies:</h1>

    @if(count($galaxes)>0)
        @foreach ($galaxes as $galax)
            <div class="well">
            <h3><a href="/galaxies/{{$galax->id}}">{{$galax->galaxy}}</a></h3>
            <small>Written on:{{$galax->created_at}}</small>
            </div>
        @endforeach
    @endif
@endsection
