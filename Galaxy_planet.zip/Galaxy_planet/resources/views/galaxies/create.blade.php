@extends('layouts.app')
@section('content')
    <h1>Create Galaxy:</h1>
    {!! Form::open(['action' => 'GalaxiesController@store','method'=>'POST']) !!}
        <div class="form-group">
            {{Form::label('galaxy','Galaxy')}}
            {{Form::text('galaxy','',['class'=>'form-control','placeholder'=> "Galaxy Name"])}}
        </div>
        {{Form::submit('Submit',['class'=>'btn btn-primary'])}}
    {!! Form::close() !!}
@endsection