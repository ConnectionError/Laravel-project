@extends('layouts.app')
@section('content')
    <a href="\galaxies" class="btn btn-default">Go Back</a>
    <h1>{{$galax->galaxy}}</h1>
    <hr>
    <h3 style="color:white">The Galaxy ID:{{$galax->id}}</h3>
    <small style="color:white">Written on: {{$galax->created_at}}</small>
    <hr>
    @if(!Auth::guest())
        <a href="/galaxies/{{$galax->id}}/edit" class="btn btn-default">Edit</a>
        {!!Form::open(['action' => ['GalaxiesController@destroy',$galax->id], 'method'=>'POST', 'class'=> 'pull-right'])!!}
            {{Form::hidden('_method', 'DELETE')}}
            {{Form::submit('Delete', ['class'=>'btn btn-danger'])}}
        {!!Form::close()!!}
    @endif
@endsection