@extends('layouts.app')
@section('content')
    <h1>Planets:</h1>

    @if(count($planets)>0)
        @foreach ($planets as $planet)
            <div class="well">
            <h3><a href="/planets/{{$planet->id}}">{{$planet->planet}}</a></h3>
            <small>Written on:{{$planet->created_at}}</small>
            </div>
        @endforeach
    @endif
@endsection
