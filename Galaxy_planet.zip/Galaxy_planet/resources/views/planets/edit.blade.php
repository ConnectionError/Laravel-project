@extends('layouts.app')
@section('content')
    <h1>Edit Planet:</h1>
    {!! Form::open(['action' => ['PlanetsController@update', $planet->id],'method'=>'POST']) !!}
        <div class="form-group">
            {{Form::label('planet','Planet')}}
            {{Form::text('planet',$planet->planet,['class'=>'form-control','placeholder'=> "Planet Name"])}}
            {{Form::label('galaxy_id','Galaxy_ID')}}
            {{Form::text('galaxy_id',$planet->galaxy_id,['class'=>'form-control','placeholder'=> "Galaxy ID"])}}
        </div>
        {{Form::hidden('_method','PUT')}}
        {{Form::submit('Submit',['class'=>'btn btn-primary'])}}
    {!! Form::close() !!}
@endsection