@extends('layouts.app')
@section('content')
    <h1>Create Planet:</h1>
    {!! Form::open(['action' => 'PlanetsController@store','method'=>'POST']) !!}
        <div class="form-group">
            {{Form::label('planet','Planet')}}
            {{Form::text('planet','',['class'=>'form-control','placeholder'=> "Planet Name"])}}
            {{Form::label('galaxy_id','Galaxy ID')}}
            {{Form::text('galaxy_id','',['class'=>'form-control','placeholder'=> "Galaxy ID"])}}
        </div>
        {{Form::submit('Submit',['class'=>'btn btn-primary'])}}
    {!! Form::close() !!}
@endsection