@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                    <h3>The user Logged in</h3>
                    <a href="/planets/create" class="btn btn-primary">Create Planet</a></li>
                    <a href="/galaxies/create" class="btn btn-primary">Create Galaxy</a></li>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><h2>Planetory System</h2></div>
                <div class="container">
                    <table style= "width:250px">
                        <tr>
                            <th class="table-heading">Planet Name</th>
                            <th class="table-heading">Galaxy Name</th>
                        </tr>
                        @if(count($galaxes)>0)
                            @foreach($galaxes as $galax)
                                @if(count($planets)>0)
                                    @foreach($planets as $planet)
                                        @if($galax->id === $planet->galaxy_id)
                                        <tr>
                                            <td>{{$planet->planet}}</td>
                                            <td>{{$galax->galaxy}}</td>
                                        </tr>
                                        @endif
                                    @endforeach
                                @endif
                            @endforeach
                        @endif
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
