<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class galax extends Model
{
    public function planet()
    {
        return $this->hasMany(Planet::class);
    }
}
