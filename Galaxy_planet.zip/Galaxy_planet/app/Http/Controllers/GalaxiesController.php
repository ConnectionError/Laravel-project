<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Galax;

class GalaxiesController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth',['except' => ['index','show']]);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $galaxes= galax::all();
        return view('galaxies.index')->with('galaxes',$galaxes);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('galaxies.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'galaxy' => 'required'
        ]);
        $galax =new Galax;
        $galax->galaxy = $request->input('galaxy');
        $galax->save();
        return redirect('/galaxies')->with('success','Galaxy Created');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $galax= Galax::find($id);
        return view('galaxies.show')->with('galax',$galax);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $galax= Galax::find($id);
        return view('galaxies.edit')->with('galax',$galax);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'galaxy' => 'required'
        ]);
        $galax =Galax::find($id);
        $galax->galaxy = $request->input('galaxy');
        $galax->save();
        return redirect('/galaxies')->with('success','Galaxy Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
