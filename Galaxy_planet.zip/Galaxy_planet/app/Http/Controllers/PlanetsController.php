<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Planet;

class PlanetsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth',['except' => ['index','show']]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $planets= Planet::all();
        return view('planets.index')->with('planets',$planets);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('planets.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'planet' => 'required'
        ]);
        $planet =new Planet;
        $planet->planet = $request->input('planet');
        $planet->galaxy_id = $request->input('galaxy_id');
        $planet->save();
        return redirect('/planets')->with('success','Planet Created');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $planet= Planet::find($id);
        return view('planets.show')->with('planet',$planet);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $planet= Planet::find($id);
        return view('planets.edit')->with('planet',$planet);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'planet' => 'required'
        ]);
        $planet =Planet::find($id);
        $planet->planet = $request->input('planet');
        $planet->galaxy_id = $request->input('galaxy_id');
        $planet->save();
        return redirect('/planets')->with('success','Planet Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $planet=Planet::find($id);
        $planet->delete();
        return redirect('/planets')->with('success','Planet Deleted');
    }
}
