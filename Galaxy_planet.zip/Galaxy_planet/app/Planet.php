<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Planet extends Model
{
    public function galax()
    {
        return $this->belongsTo(Galax::class);
    }
}
